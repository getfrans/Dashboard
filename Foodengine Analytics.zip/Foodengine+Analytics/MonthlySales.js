lib('cdf-env.js');

var render_MonthlySales = {
  type: "cccBarChart",
  name: "render_MonthlySales",
  priority: 5,
  parameters: [["branchParam","branchParam"]],
  executeAtStart: true,
  htmlObject: "${h:MonthlySalesDiv}",
  preExecution: function f(){
    var valuePreffix = 'Rs.';
    
    steelwheels.barChartOptions.apply(this);
    steelwheels.yearLabelsOptions.apply(this);    
    steelwheels.kpiTooltipOptions.call(this, valuePreffix);    
    steelwheels.barChartHoverableOptions.apply(this);
} 
 ,
  listeners: ["${p:branchParam}","${p:userParam}"],
  chartDefinition:  {
    dataAccessId: "monthlySalesSQL",
    path: "/home/admin/Foodengine Analytics/SalesOverview.cda",
    height: 300,
    extensionPoints: [],
    colors: [],
    animate: true,
    barOrthoSizeMin: 1.5,
    barStackedMargin: 0,
    baseAxisLabelDesiredAngles: [],
    baseAxisOffset: 0,
    baseAxisTicks: true,
    baseAxisTitleMargins: "0",
    baseAxisTooltipAutoContent: "value",
    baseAxisTooltipEnabled: true,
    baseAxisVisible: true,
    clearSelectionMode: "emptySpaceClick",
    clickable: true,
    clickAction: function f(scene){
    
//alert("series = " + scene.vars.series.value + "\ncategory = " + scene.vars.category.value + "\nvalue = " + scene.vars.value.value);

Dashboards.fireChange('chartMonthParam',scene.vars.category.value);
//alert(chartMonthParam);
document.getElementById("daytitle").innerHTML ="";
document.getElementById("daytitle").innerHTML ="<span class='glyphicon glyphicon-signal'></span>Daily Sales Trend";
document.getElementById("DaySalesDiv").style.display='block';
document.getElementById("backimage").style.display='block';
document.getElementById("daytitle").style.display='block';
document.getElementById("daytitle").innerHTML+= " for <span style='color:#FDEDED'>" + chartMonthParam + "</span>&nbsp;";

document.getElementById("monthtitle").style.display='none';
document.getElementById("MonthlySalesDiv").style.display='none';
document.getElementById("charthint").style.display='none';
}


 ,
    color2AxisColors: [],
    color2AxisLegendClickMode: "toggleVisible",
    color2AxisLegendVisible: true,
    color2AxisPreserveMap: false,
    colorPreserveMap: false,
    compatVersion: 3,
    crosstabMode: true,
    ctrlSelectMode: true,
    dataIgnoreMetadataLabels: false,
    dataSeparator: "~",
    groupedLabelSep: " ~ ",
    hoverable: false,
    ignoreNulls: true,
    isMultiValued: false,
    leafContentOverflow: "auto",
    legendClickMode: "toggleVisible",
    legendFont: "12px sans-serif",
    legendVisible: true,
    measuresIndexes: [],
    multiChartColumnsMax: 3,
    multiChartIndexes: [],
    multiChartOverflow: "grow",
    multiChartSingleColFillsHeight: true,
    multiChartSingleRowFillsHeight: true,
    nullInterpolationMode: "none",
    orientation: "vertical",
    ortho2AxisDomainAlign: "center",
    ortho2AxisDomainRoundMode: "tick",
    ortho2AxisDomainScope: "global",
    ortho2AxisMinorTicks: true,
    ortho2AxisOffset: 0,
    ortho2AxisTicks: true,
    ortho2AxisTickUnitMax: "Infinity",
    ortho2AxisTickUnitMin: "0",
    ortho2AxisTitleFont: "12px sans-serif",
    ortho2AxisTitleMargins: "0",
    ortho2AxisVisible: true,
    ortho2AxisZeroLine: true,
    orthoAxisDomainAlign: "center",
    orthoAxisDomainRoundMode: "tick",
    orthoAxisDomainScope: "global",
    orthoAxisOffset: 0,
    orthoAxisTicks: true,
    orthoAxisTickUnitMax: "Infinity",
    orthoAxisTickUnitMin: "0",
    orthoAxisTitleMargins: "0",
    orthoAxisVisible: true,
    orthoAxisZeroLine: true,
    overflowMarkersVisible: true,
    plot2: false,
    plot2AreasFillOpacity: 0.5,
    plot2AreasVisible: false,
    plot2ColorAxis: 2,
    plot2DotsVisible: true,
    plot2LinesVisible: true,
    plot2NullInterpolationMode: "none",
    plot2OrthoAxis: 1,
    plot2Series: [],
    plot2SeriesIndexes: -1,
    plot2Stacked: false,
    plot2ValuesMask: "{value}",
    plot2ValuesVisible: false,
    pointingMode: "near",
    preserveLayout: false,
    readers: [],
    selectable: false,
    seriesInRows: false,
    slidingWindow: false,
    smallContentMargins: "0",
    smallContentPaddings: "0",
    smallMargins: "2%",
    smallPaddings: "0",
    smallTitleFont: "14px sans-serif",
    smallTitleMargins: "0",
    smallTitlePaddings: "0",
    smallTitlePosition: "top",
    stacked: false,
    timeSeries: false,
    timeSeriesFormat: "%Y-%m-%d",
    titleFont: "14px sans-serif",
    titleMargins: "0",
    titlePaddings: "0",
    tooltipEnabled: true,
    tooltipFade: true,
    tooltipFollowMouse: false,
    tooltipHtml: true,
    tooltipOpacity: 0.9,
    trendAreasFillOpacity: 0.5,
    trendAreasVisible: false,
    trendColorAxis: 2,
    trendDotsVisible: false,
    trendLinesVisible: true,
    trendOrthoAxis: 1,
    trendStacked: false,
    trendValuesAnchor: "right",
    trendValuesVisible: false,
    valuesNormalized: false,
    valuesOverflow: "hide"
  }
};

cgg.initParameter
("userParam", "${[session:name]}")
("branchParam", "branchParam")
;

cgg.render(render_MonthlySales);
